@echo off
echo vcpkg binary provided by Compendium - skipping bootstrap
