#!/bin/sh
echo "vcpkg binary provided by Compendium — skipping bootstrap"
